"""
inference.py

Main inference script for the SignBart Sign Language Recognition model.

Usage
-----
# Run with mock (dummy) features (no real video needed):
    python inference.py

# Run with a real pre-extracted feature file:
    python inference.py --features path/to/features.pt

# Specify custom checkpoint directory:
    python inference.py --checkpoint_dir path/to/checkpoint_dir

Command-line arguments
----------------------
--checkpoint_dir  Directory containing config.json and model.safetensors.
                  Defaults to the current working directory.
--features        Path to a .pt or .npy feature file (optional).
                  When omitted, random dummy features are used.
--batch_size      Number of samples in the mock batch (default: 2).
--seq_len         Frame count for mock features (default: 30).
--max_new_tokens  Maximum tokens to generate per sample (default: 20).
--device          "cpu" or "cuda" (default: auto-detect).
--beam_size       Number of beams for beam-search decoding (default: 4).
"""

import argparse
import os
import sys
from pathlib import Path

import torch

# ---------------------------------------------------------------------------
# Resolve project root so that `models` and `utils` are importable whether
# the script is run from the project root or from any other working directory.
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from models.sign_bart import SignBart, SignBartConfig
from utils.data_utils import (
    build_id2label,
    create_mock_video_features,
    decode_batch,
    load_config,
    load_features_from_file,
)


# --------------------------------------------------------------------------- #
# Helpers                                                                      #
# --------------------------------------------------------------------------- #

def build_sign_bart_config(raw_config: dict, input_feature_dim: int) -> SignBartConfig:
    """
    Construct a SignBartConfig from the parsed config.json dict.

    Only the fields that BartConfig / SignBartConfig actually use are forwarded;
    unknown keys are silently dropped so the function is robust to future
    checkpoint changes.

    Parameters
    ----------
    raw_config : dict
        Output of ``load_config()``.
    input_feature_dim : int
        Dimensionality of the video feature vectors fed to the encoder.

    Returns
    -------
    SignBartConfig
    """
    # Fields supported by BartConfig that we want to carry over from the JSON
    KNOWN_BART_FIELDS = {
        "vocab_size",
        "max_position_embeddings",
        "encoder_layers",
        "encoder_ffn_dim",
        "encoder_attention_heads",
        "decoder_layers",
        "decoder_ffn_dim",
        "decoder_attention_heads",
        "encoder_layerdrop",
        "decoder_layerdrop",
        "activation_function",
        "d_model",
        "dropout",
        "attention_dropout",
        "activation_dropout",
        "init_std",
        "classifier_dropout",
        "scale_embedding",
        "use_cache",
        "num_labels",
        "pad_token_id",
        "bos_token_id",
        "eos_token_id",
        "is_encoder_decoder",
        "decoder_start_token_id",
        "forced_eos_token_id",
        "id2label",
        "label2id",
    }

    filtered = {k: v for k, v in raw_config.items() if k in KNOWN_BART_FIELDS}

    # id2label keys must be integers for BartConfig
    if "id2label" in filtered:
        filtered["id2label"] = {int(k): v for k, v in filtered["id2label"].items()}

    config = SignBartConfig(
        input_feature_dim=input_feature_dim,
        **filtered,
    )
    return config


def print_separator(title: str = "", width: int = 70) -> None:
    if title:
        pad = (width - len(title) - 2) // 2
        print("=" * pad + f" {title} " + "=" * (width - pad - len(title) - 2))
    else:
        print("=" * width)


# --------------------------------------------------------------------------- #
# Main inference routine                                                       #
# --------------------------------------------------------------------------- #

def run_inference(args: argparse.Namespace) -> None:
    # ---------------------------------------------------------------------- #
    # 0. Setup                                                                #
    # ---------------------------------------------------------------------- #
    print_separator("SignBart Sign Language Recognition — Inference")

    checkpoint_dir = Path(args.checkpoint_dir)
    config_path    = checkpoint_dir / "config.json"
    weights_path   = checkpoint_dir / "model.safetensors"

    for p in (config_path, weights_path):
        if not p.is_file():
            raise FileNotFoundError(
                f"Required file not found: {p}\n"
                f"Make sure --checkpoint_dir points to the folder containing "
                f"config.json and model.safetensors."
            )

    device = args.device
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"  Device            : {device}")

    # ---------------------------------------------------------------------- #
    # 1. Load config.json and build SignBartConfig                            #
    # ---------------------------------------------------------------------- #
    print("\n[1/4] Loading config …")
    raw_config  = load_config(str(config_path))
    id2label    = build_id2label(raw_config)
    d_model: int = raw_config.get("d_model", 256)

    # input_feature_dim: the raw video feature dimensionality.
    # For this checkpoint features are already d_model-dimensional (256).
    input_feature_dim: int = args.input_feature_dim if args.input_feature_dim else d_model

    print(f"  d_model           : {d_model}")
    print(f"  input_feature_dim : {input_feature_dim}")
    print(f"  vocab_size        : {raw_config.get('vocab_size')}")
    print(f"  num_labels        : {len(id2label)}")
    print(f"  encoder_layers    : {raw_config.get('encoder_layers')}")
    print(f"  decoder_layers    : {raw_config.get('decoder_layers')}")

    config = build_sign_bart_config(raw_config, input_feature_dim=input_feature_dim)

    # ---------------------------------------------------------------------- #
    # 2. Instantiate model and load weights from model.safetensors            #
    # ---------------------------------------------------------------------- #
    print("\n[2/4] Building model and loading safetensors weights …")
    model = SignBart.from_safetensors(
        config=config,
        safetensors_path=str(weights_path),
        strict=False,   # tolerate missing feature_projection key in checkpoint
        device=device,
    )
    model.eval()

    total_params = sum(p.numel() for p in model.parameters())
    print(f"  Total parameters  : {total_params:,}")

    # ---------------------------------------------------------------------- #
    # 3. Prepare input features                                               #
    # ---------------------------------------------------------------------- #
    print("\n[3/4] Preparing input features …")

    if args.features:
        print(f"  Loading real features from: {args.features}")
        video_features, attention_mask = load_features_from_file(
            args.features, device=device
        )
    else:
        print(
            f"  No --features path supplied.  "
            f"Using mock features "
            f"(batch={args.batch_size}, seq_len={args.seq_len}, dim={input_feature_dim})."
        )
        video_features, attention_mask = create_mock_video_features(
            batch_size=args.batch_size,
            sequence_length=args.seq_len,
            feature_dim=input_feature_dim,
            seed=42,
            device=device,
        )

    print(f"  video_features shape  : {tuple(video_features.shape)}")
    print(f"  attention_mask shape  : {tuple(attention_mask.shape)}")

    # ---------------------------------------------------------------------- #
    # 4. Run model.generate()                                                 #
    # ---------------------------------------------------------------------- #
    print("\n[4/4] Running model.generate() …")

    # Determine generation special token IDs from the config
    bos_token_id    = config.bos_token_id    if config.bos_token_id    is not None else 0
    eos_token_id    = config.eos_token_id    if config.eos_token_id    is not None else 1
    pad_token_id    = config.pad_token_id    if config.pad_token_id    is not None else 0
    decoder_start   = config.decoder_start_token_id
    if decoder_start is None:
        # Fall back: use bos or the first label ID
        decoder_start = bos_token_id

    print(f"  bos_token_id          : {bos_token_id}")
    print(f"  eos_token_id          : {eos_token_id}")
    print(f"  decoder_start_token_id: {decoder_start}")
    print(f"  max_new_tokens        : {args.max_new_tokens}")
    print(f"  num_beams             : {args.beam_size}")

    with torch.no_grad():
        generated_ids = model.generate(
            inputs_embeds=video_features,          # encoder input (projected internally)
            attention_mask=attention_mask,
            decoder_start_token_id=decoder_start,
            bos_token_id=bos_token_id,
            eos_token_id=eos_token_id,
            pad_token_id=pad_token_id,
            max_new_tokens=args.max_new_tokens,
            num_beams=args.beam_size,
            early_stopping=True,
        )

    # ---------------------------------------------------------------------- #
    # 5. Decode and print results                                             #
    # ---------------------------------------------------------------------- #
    print_separator("Results")
    decoded_labels = decode_batch(generated_ids, id2label, skip_special_tokens=True)

    for i, (ids, text) in enumerate(zip(generated_ids, decoded_labels)):
        raw_ids_str = ids.tolist()
        print(f"\n  Sample {i + 1}:")
        print(f"    Generated token IDs : {raw_ids_str}")
        print(f"    Predicted labels    : {text if text else '(empty — only special tokens generated)'}")

    print_separator()
    print("Inference complete.\n")


# --------------------------------------------------------------------------- #
# CLI                                                                          #
# --------------------------------------------------------------------------- #

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="SignBart sign-language inference script.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--checkpoint_dir",
        type=str,
        default=".",
        help=(
            "Directory that contains config.json and model.safetensors.  "
            "Defaults to the current working directory."
        ),
    )
    parser.add_argument(
        "--features",
        type=str,
        default=None,
        help=(
            "Path to a pre-extracted feature file (.pt or .npy).  "
            "If omitted, random mock features are generated."
        ),
    )
    parser.add_argument(
        "--input_feature_dim",
        type=int,
        default=None,
        help=(
            "Dimensionality of the raw video features.  "
            "Defaults to d_model (256) from config.json."
        ),
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=2,
        help="Batch size used when generating mock features.",
    )
    parser.add_argument(
        "--seq_len",
        type=int,
        default=30,
        help="Sequence length (frames) used when generating mock features.",
    )
    parser.add_argument(
        "--max_new_tokens",
        type=int,
        default=20,
        help="Maximum number of new tokens to generate.",
    )
    parser.add_argument(
        "--beam_size",
        type=int,
        default=4,
        help="Number of beams for beam-search decoding.",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        choices=["auto", "cpu", "cuda"],
        help='Computation device.  "auto" selects CUDA when available.',
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_inference(args)
