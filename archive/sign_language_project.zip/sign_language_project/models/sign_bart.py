"""
models/sign_bart.py

Custom SignBart architecture for Sign Language Recognition.

Architecture overview:
  - Encoder: BartEncoder that accepts pre-extracted video feature vectors
    (shape: batch_size x seq_len x input_feature_dim) instead of token IDs.
    A linear projection layer maps input_feature_dim → d_model (256) when
    input_feature_dim != d_model.
  - Decoder: Standard BartDecoder that auto-regressively generates label tokens.
  - Classification Head: Linear layer projecting decoder hidden states to vocab_size.

Weight keys in model.safetensors are expected to follow the naming convention:
  encoder.layers.*  /  decoder.embed_tokens.*  /  classification_head.out_proj.*
which maps 1-to-1 to this class's state_dict keys.
"""

import torch
import torch.nn as nn
from transformers import BartConfig, BartForConditionalGeneration
from transformers.modeling_outputs import Seq2SeqLMOutput


class SignBartConfig(BartConfig):
    """
    Extended BartConfig that adds SignBart-specific fields.

    Extra fields
    ------------
    input_feature_dim : int
        Dimensionality of the raw video feature vectors fed to the encoder.
        When this differs from d_model the model inserts a learned linear
        projection.  Defaults to d_model so no projection is added for the
        standard checkpoint.
    model_type : str
        Registered model-type string.  Must be "SignBart" to match the
        config.json that ships with the checkpoint.
    """

    model_type = "SignBart"

    def __init__(self, input_feature_dim: int = None, **kwargs):
        super().__init__(**kwargs)
        # If the caller did not supply input_feature_dim, fall back to d_model
        # so that the projection layer becomes an identity-equivalent linear
        # (it is still created but initialised as identity-weight → fine-tune).
        self.input_feature_dim = input_feature_dim if input_feature_dim is not None else self.d_model


class SignBart(BartForConditionalGeneration):
    """
    SignBart – Sign Language Recognition model.

    Inherits from BartForConditionalGeneration so that:
      • model.generate() works out of the box.
      • All BART utilities (beam search, greedy decoding, …) are available.
      • Loading the safetensors checkpoint is straightforward via load_state_dict.

    Key customisation
    -----------------
    A ``feature_projection`` linear layer is prepended to the BART encoder.
    When ``input_feature_dim == d_model`` the projection is still present but
    acts as a re-parameterised identity, keeping the state_dict clean.

    The standard BART shared embedding (``model.shared``) is *not* used on the
    encoder side; the encoder always receives ``inputs_embeds`` produced by
    ``feature_projection``.
    """

    config_class = SignBartConfig

    def __init__(self, config: SignBartConfig):
        super().__init__(config)

        # ------------------------------------------------------------------ #
        # Feature projection: video_feature_dim → d_model                    #
        # ------------------------------------------------------------------ #
        self.feature_projection = nn.Linear(
            config.input_feature_dim,
            config.d_model,
            bias=True,
        )

        # Initialise projection as near-identity when dims match to give a
        # sensible starting point if the checkpoint does not contain this key.
        if config.input_feature_dim == config.d_model:
            nn.init.eye_(self.feature_projection.weight)
            nn.init.zeros_(self.feature_projection.bias)
        else:
            nn.init.xavier_uniform_(self.feature_projection.weight)
            nn.init.zeros_(self.feature_projection.bias)

        # Re-initialise weights as BartForConditionalGeneration does
        # (this call is already made in the parent __init__, but we call it
        # again so that feature_projection is included).
        self.post_init()

    # ---------------------------------------------------------------------- #
    # Forward pass                                                            #
    # ---------------------------------------------------------------------- #

    def forward(
        self,
        input_ids=None,                   # NOT used on the encoder side
        attention_mask=None,
        decoder_input_ids=None,
        decoder_attention_mask=None,
        head_mask=None,
        decoder_head_mask=None,
        cross_attn_head_mask=None,
        encoder_outputs=None,
        past_key_values=None,
        inputs_embeds=None,               # Raw video features (B, T, input_feature_dim)
        decoder_inputs_embeds=None,
        labels=None,
        use_cache=None,
        output_attentions=None,
        output_hidden_states=None,
        return_dict=None,
    ) -> Seq2SeqLMOutput:
        """
        Parameters
        ----------
        inputs_embeds : torch.Tensor, shape (B, T, input_feature_dim)
            Pre-extracted video feature sequence.  This is the primary input
            on the encoder side – ``input_ids`` is intentionally ignored for
            the encoder.
        All other parameters are identical to BartForConditionalGeneration.
        """

        # Project raw features to d_model before passing to the encoder
        if inputs_embeds is not None and encoder_outputs is None:
            inputs_embeds = self.feature_projection(inputs_embeds)  # (B, T, d_model)

        return super().forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            decoder_input_ids=decoder_input_ids,
            decoder_attention_mask=decoder_attention_mask,
            head_mask=head_mask,
            decoder_head_mask=decoder_head_mask,
            cross_attn_head_mask=cross_attn_head_mask,
            encoder_outputs=encoder_outputs,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            decoder_inputs_embeds=decoder_inputs_embeds,
            labels=labels,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
        )

    # ---------------------------------------------------------------------- #
    # generate() helper: route video features through the encoder once        #
    # ---------------------------------------------------------------------- #

    def prepare_inputs_for_generation(
        self,
        decoder_input_ids,
        past_key_values=None,
        attention_mask=None,
        decoder_attention_mask=None,
        head_mask=None,
        decoder_head_mask=None,
        cross_attn_head_mask=None,
        use_cache=None,
        encoder_outputs=None,
        **kwargs,
    ):
        """
        Overrides the parent method so that ``inputs_embeds`` (video features)
        stored in ``kwargs`` are passed along during the first decoding step.
        From the second step onward encoder_outputs is already cached and
        inputs_embeds is not needed.
        """
        model_inputs = super().prepare_inputs_for_generation(
            decoder_input_ids,
            past_key_values=past_key_values,
            attention_mask=attention_mask,
            decoder_attention_mask=decoder_attention_mask,
            head_mask=head_mask,
            decoder_head_mask=decoder_head_mask,
            cross_attn_head_mask=cross_attn_head_mask,
            use_cache=use_cache,
            encoder_outputs=encoder_outputs,
            **kwargs,
        )
        return model_inputs

    # ---------------------------------------------------------------------- #
    # Convenience: load from a safetensors file                               #
    # ---------------------------------------------------------------------- #

    @classmethod
    def from_safetensors(
        cls,
        config: SignBartConfig,
        safetensors_path: str,
        strict: bool = False,
        device: str = "cpu",
    ) -> "SignBart":
        """
        Instantiate SignBart from a ``model.safetensors`` checkpoint.

        Parameters
        ----------
        config : SignBartConfig
        safetensors_path : str
            Path to ``model.safetensors``.
        strict : bool
            Passed directly to ``load_state_dict``.  Defaults to ``False`` so
            that keys present in the checkpoint but not in the model (or vice
            versa, such as ``feature_projection``) do not raise errors.
        device : str
            Target device for the loaded tensors.

        Returns
        -------
        SignBart
        """
        from safetensors.torch import load_file

        model = cls(config)
        state_dict = load_file(safetensors_path, device=device)

        missing, unexpected = model.load_state_dict(state_dict, strict=strict)

        if missing:
            print(f"[SignBart] Missing keys ({len(missing)}):")
            for k in missing[:10]:
                print(f"    {k}")
            if len(missing) > 10:
                print(f"    … and {len(missing) - 10} more")

        if unexpected:
            print(f"[SignBart] Unexpected keys ({len(unexpected)}):")
            for k in unexpected[:10]:
                print(f"    {k}")
            if len(unexpected) > 10:
                print(f"    … and {len(unexpected) - 10} more")

        model.to(device)
        model.eval()
        return model
